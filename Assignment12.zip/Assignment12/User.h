#include <iostream> // for CLI
#include <string> // Include the string library

class User {
    private: 
        //All info is private
        float weight; 
        float height;
        std::string name;
        int BMI;

        // Bounds for BMI classification
        int Uunderweight = 18.5; //upper bound underweight
        int Unormal = 24.9; //upper bound normal weight 
        int Lnormal = 18.5; //upper bound normal weight 
        int Uoverweight = 29.9; //upper bound overwSSeight
        int Loverweight = 25; //upper bound overweight
        int Lobese = 30; // Lower bound obese
        std::string status; //Status for storing BMI classification after evaluation


    public:
        //declaring getter and setter functions. 
        void inputInfo();

        void evaluateAndPrintBMI();

        void printInfo();
};