#include "User.h"
#include <string> // Include the string library
#include <iostream>

using namespace std;
int main()
{
    User u1;
    u1.printInfo();
    u1.inputInfo();

    u1.evaluateAndPrintBMI();
    
    return 0;
}
