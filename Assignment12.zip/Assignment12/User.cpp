#include "User.h"
#include <iostream>
#include <string> // Include the string library

using namespace std;


void User::evaluateAndPrintBMI(){
    cout << "The BMI of " << name << " is " << BMI; 
    //Evaluate the BMI of the user against the norms defined in the class
    if (BMI<Uunderweight){
        status = "underweight";
    } else if (BMI < Unormal) {
        status = "normal";
    } else if (BMI < Uoverweight){
        status = "overweight";
    } else { // If the BMI is not under the upper bound of overweight, the user is classified as obese
        status = "obese";
    }
    cout << ". This is considered " << status << endl; //output the result to the command line
    return ;
}

void User::inputInfo(){
    //get height
    cout << "Enter your height in centimeters:";
    int cmheight; //Define cm height to allow integer input and command line
    cin >> cmheight;
    height = (float)cmheight/(float)100; //Convert back to meters

    //get weight
    cout << "Enter your weight in kilograms:";
    cin >> weight; 

    //get name
    cout << "Enter your name:";
    cin >> name;

    //calculate BMI
    BMI = weight/(height*height); 
}

void User::printInfo(){
    //Print the upper and lower bounds for the BMI classifications.
    cout << "BMI VALUES:" << endl;
    cout << "Underweight: less than " << Uunderweight << endl;
    cout << "Normal:      between " << Lnormal << " and " << Unormal << endl;
    cout << "Overweight:  between " << Loverweight << " and " << Uoverweight << endl;
    cout << "Obese:       over " << Lobese << endl;
}